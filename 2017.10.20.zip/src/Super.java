class Employee{
	private String empNo;
	private String name;
	private String part;
	
	public Employee() {
	}
	public Employee(String empNo, String name, String part) {
		this.empNo = empNo;
		this.name = name;
		this.part = part;
	}
	public String getEmpNo() {
		return empNo;
	};
	public String getName() {
		return name;
	};
	public String getPart() {
		return part;
	};
	public void setEmpNo(String empNo) {
		this.empNo = empNo;
	};
	public void setName(String name) {
		this.name = name;
	};
	public void setPart(String part) {
		this.part = part;
	};
	public String resultStr() {
		String result = "";
		
		result += "��� : " + empNo + "\n";
		result += "�̸� : " + name + "\n";
		result += "�μ� : " + part + "\n";
		
		return result;
	}
}
class Manager extends Employee{
	private String position;
	
	public Manager(String empNo, String name, String part, String position) {
		super(empNo, name, part);
		this.position = position;
	}
	public String addStr() {
		String result = super.resultStr();
		result += "��å : " + position + "\n";
		return result;
	}
}
public class Super {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	}

}
