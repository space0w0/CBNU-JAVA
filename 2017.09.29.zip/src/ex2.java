
public class ex2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] exmoney = {500, 100, 50, 10};
		int money = 1680;
		System.out.println("money=" + money);
		for(int i=0; i<exmoney.length; i++) {
			int a = money/exmoney[i];
			money = money%exmoney[i];
			System.out.println(exmoney[i] + "�� = " + a + "��");
		}
	}
}
